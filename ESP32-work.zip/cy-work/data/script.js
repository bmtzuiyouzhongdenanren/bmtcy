// EventSource setup to receive real-time data
if (!!window.EventSource) {
  var source = new EventSource('/events');

  source.addEventListener('open', function(e) {
    console.log("Events Connected");
  }, false);

  source.addEventListener('error', function(e) {
    if (e.target.readyState != EventSource.OPEN) {
      console.log("Events Disconnected");
    }
  }, false);

  // Handle temperature readings
  source.addEventListener('temperature_reading', function(e) {
    document.getElementById("temp").innerHTML = e.data + " °C";
  }, false);
}
